from flask import Flask, request, jsonify, render_template
import joblib
import numpy as np
import pandas as pd
import shap
import lime
import lime.lime_tabular
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)

# Load model and data once at startup
print("Loading model...")
model = joblib.load('best_model.pkl')
X_train = pd.read_csv('X_train.csv')
feature_names = X_train.columns.tolist()

# LIME explainer
lime_explainer = lime.lime_tabular.LimeTabularExplainer(
    X_train.values,
    feature_names=feature_names,
    class_names=['Legitimate', 'Phishing'],
    mode='classification',
    random_state=42
)

# SHAP explainer
shap_explainer = shap.TreeExplainer(model)

print(f"✓ Model loaded | Features: {len(feature_names)}")

# ============================================
# ROUTES
# ============================================

@app.route('/')
def home():
    return render_template('index.html', feature_names=feature_names)


@app.route('/predict', methods=['POST'])
def predict():
    """
    Endpoint: /predict
    Method: POST
    Input:  JSON with feature values
    Output: JSON with prediction + probability
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        # Build feature vector
        features = []
        for feat in feature_names:
            val = data.get(feat, 0)
            features.append(float(val))

        features_array = np.array(features).reshape(1, -1)

        # Predict
        prediction   = int(model.predict(features_array)[0])
        probability  = model.predict_proba(features_array)[0]
        label        = 'Phishing' if prediction == 1 else 'Legitimate'
        confidence   = float(max(probability))

        return jsonify({
            'status':         'success',
            'prediction':     prediction,
            'label':          label,
            'confidence':     round(confidence * 100, 2),
            'prob_legitimate': round(float(probability[0]) * 100, 2),
            'prob_phishing':   round(float(probability[1]) * 100, 2)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/explain', methods=['POST'])
def explain():
    """
    Endpoint: /explain
    Method: POST
    Input:  JSON with feature values
    Output: JSON with LIME explanation (top 10 feature contributions)
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        features = [float(data.get(feat, 0)) for feat in feature_names]
        features_array = np.array(features)

        # LIME explanation
        exp = lime_explainer.explain_instance(
            features_array,
            model.predict_proba,
            num_features=10
        )
        label_key = exp.available_labels()[0]
        items = exp.as_list(label=label_key)

        explanation = [
            {'feature': item[0], 'weight': round(item[1], 4)}
            for item in items
        ]

        # Prediction info
        pred_label   = int(model.predict(features_array.reshape(1, -1))[0])
        probability  = model.predict_proba(features_array.reshape(1, -1))[0]

        return jsonify({
            'status':          'success',
            'prediction':      'Phishing' if pred_label == 1 else 'Legitimate',
            'prob_phishing':   round(float(probability[1]) * 100, 2),
            'prob_legitimate': round(float(probability[0]) * 100, 2),
            'explanation':     explanation,
            'interpretation': (
                'Red/positive weights push toward PHISHING. '
                'Green/negative weights push toward LEGITIMATE.'
            )
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/shap_explain', methods=['POST'])
def shap_explain():
    """
    Endpoint: /shap_explain
    Method: POST
    Input:  JSON with feature values
    Output: JSON with top SHAP values
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        features = np.array([float(data.get(feat, 0)) for feat in feature_names]).reshape(1, -1)

        sv_raw = shap_explainer.shap_values(features)
        if isinstance(sv_raw, list):
            sv = sv_raw[1][0]
        elif len(np.array(sv_raw).shape) == 3:
            sv = np.array(sv_raw)[0, :, 1]
        else:
            sv = np.array(sv_raw)[0]

        top_idx = np.argsort(np.abs(sv))[-10:][::-1]
        shap_result = [
            {'feature': feature_names[i], 'shap_value': round(float(sv[i]), 4)}
            for i in top_idx
        ]

        pred = int(model.predict(features)[0])
        prob = model.predict_proba(features)[0]

        return jsonify({
            'status':          'success',
            'prediction':      'Phishing' if pred == 1 else 'Legitimate',
            'prob_phishing':   round(float(prob[1]) * 100, 2),
            'prob_legitimate': round(float(prob[0]) * 100, 2),
            'shap_values':     shap_result
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status':    'healthy',
        'model':     'Random Forest - Phishing Detector',
        'features':  len(feature_names),
        'endpoints': ['/predict', '/explain', '/shap_explain', '/health']
    })


@app.route('/features', methods=['GET'])
def features():
    """Returns list of all required feature names"""
    return jsonify({
        'total_features': len(feature_names),
        'feature_names':  feature_names
    })


if __name__ == '__main__':
    print("\n" + "="*60)
    print("  PHISHING DETECTION API - FLASK SERVER")
    print("="*60)
    print("  Endpoints:")
    print("  GET  /            → Web Interface")
    print("  POST /predict     → Get Prediction")
    print("  POST /explain     → LIME Explanation")
    print("  POST /shap_explain→ SHAP Explanation")
    print("  GET  /health      → Health Check")
    print("  GET  /features    → Feature Names")
    print("="*60)
    app.run(debug=True, host='0.0.0.0', port=5000)
